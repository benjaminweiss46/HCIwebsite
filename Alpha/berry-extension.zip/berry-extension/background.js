console.log("Welcome to the terminal")
